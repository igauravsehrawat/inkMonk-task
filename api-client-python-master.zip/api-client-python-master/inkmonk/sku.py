from resource import Resource


class SKU(Resource):

    _resource_ = 'skus'
