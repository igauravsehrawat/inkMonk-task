from resource import Resource


class Shipment(Resource):

    _resource_ = 'shipments'
