from resource import Resource


class Customer(Resource):

    _resource_ = 'customers'
