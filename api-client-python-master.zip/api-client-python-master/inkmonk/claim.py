from resource import Resource


class Claim(Resource):

    _resource_ = 'claims'


