from resource import Resource


class Merchandise(Resource):

    _resource_ = 'merchandise'
